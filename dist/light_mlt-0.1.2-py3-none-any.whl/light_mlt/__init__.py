"""Lightweight Modular Linear Tokenization (MLT) utilities."""
__version__ = "0.1.0"
